{{/*
Expand the name of the chart.
*/}}
{{- define "opensearch-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "opensearch-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "opensearch-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "opensearch-operator.labels" -}}
helm.sh/chart: {{ include "opensearch-operator.chart" . }}
{{ include "opensearch-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "opensearch-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "opensearch-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "opensearch-operator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "opensearch-operator.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Return whether deprecated opensearch.opster.io/v1 API support is enabled.
Missing legacyAPI values default to true for upgrade compatibility.
*/}}
{{- define "opensearch-operator.legacyAPIEnabled" -}}
{{- if hasKey .Values "legacyAPI" -}}
{{- if .Values.legacyAPI -}}
{{- ne .Values.legacyAPI.enabled false -}}
{{- else -}}
true
{{- end -}}
{{- else -}}
true
{{- end -}}
{{- end }}
